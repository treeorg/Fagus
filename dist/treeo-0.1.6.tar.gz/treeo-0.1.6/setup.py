# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['treeo']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'treeo',
    'version': '0.1.6',
    'description': 'Library to easily create, edit and traverse nested objects of dicts and lists in Python',
    'long_description': '# TreeO\n',
    'author': 'Lukas Neuenschwander',
    'author_email': 'fjellvannet@gmail.com',
    'maintainer': 'treeorg',
    'maintainer_email': None,
    'url': 'https://github.com/treeorg/TreeO',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
