# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fagus']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'fagus',
    'version': '1.0.0',
    'description': 'Library to easily create, edit and traverse nested objects of dicts and lists in Python',
    'long_description': '# Fagus\n',
    'author': 'Lukas Neuenschwander',
    'author_email': 'fjellvannet@gmail.com',
    'maintainer': 'treeorg',
    'maintainer_email': None,
    'url': 'https://github.com/treeorg/Fagus',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
