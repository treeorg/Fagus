# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['treeo']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'treeo',
    'version': '0.1.0',
    'description': 'Library to easily create, edit and traverse nested objects of dicts and lists in Python',
    'long_description': None,
    'author': 'Lukas Neuenschwander',
    'author_email': 'fjellvannet@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6.2,<4.0.0',
}


setup(**setup_kwargs)
